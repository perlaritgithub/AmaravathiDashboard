import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closeevent',
  templateUrl: './closeevent.component.html',
  styleUrls: ['./closeevent.component.scss']
})
export class CloseeventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
