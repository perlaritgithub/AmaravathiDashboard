export class LoginModel {
  usr_nm  : number;  // user number for sign in
  usr_pwd : string;  // user password for sign in
}
